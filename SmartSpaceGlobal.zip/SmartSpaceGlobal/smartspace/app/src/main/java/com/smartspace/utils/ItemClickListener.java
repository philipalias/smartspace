package com.smartspace.utils;

import android.view.View;

public interface ItemClickListener {
    void onClick(View view, int position);
}
