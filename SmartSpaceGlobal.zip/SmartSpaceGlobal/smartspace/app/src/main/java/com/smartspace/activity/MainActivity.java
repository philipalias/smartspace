package com.smartspace.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.smartspace.R;
import com.smartspace.adapter.RoomAdapter;
import com.smartspace.model.RoomListData;
import com.smartspace.services.Webservices;
import com.smartspace.utils.Common;
import com.smartspace.utils.ItemClickListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.concurrent.CopyOnWriteArrayList;

public class MainActivity extends AppCompatActivity implements ItemClickListener {

    String API_ROOM_LIST = "/room/rooms.json";
    CopyOnWriteArrayList<RoomListData> roomListDataArray;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getRoomList();
    }


    public void getRoomList() {
        String url = Common.TAG_API_URL + API_ROOM_LIST;
        Common.vLog(url);
        Webservices.get(true, this, url, new Webservices.VolleyCallback() {
            @Override
            public void onSuccess(JSONArray response) {
                try {
                        roomListDataArray = new CopyOnWriteArrayList<>();
                        if(response.length() > 0){
                            for (int i= 0; i <response.length(); i++){
                                String key = response.getJSONObject(i).getString("key");
                                String name = response.getJSONObject(i).getString("name");
                                String capacity = response.getJSONObject(i).getString("capacity");
                                String thumb = response.getJSONObject(i).getString("thumbnailUrl");

                                RoomListData roomListData = new RoomListData();
                                roomListData.setKey(key);
                                roomListData.setName(name);
                                roomListData.setCapacity(capacity);
                                roomListData.setThumb(thumb);

                                roomListDataArray.add(roomListData);
                            }
                            setRoomList(roomListDataArray);
                        }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    public void setRoomList(CopyOnWriteArrayList<RoomListData> roomListArray) {

        try {

            RecyclerView roomList = (RecyclerView) findViewById(R.id.roomList);
            RoomAdapter roomListAdapter = new RoomAdapter(roomListArray, this);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
            roomList.setLayoutManager(linearLayoutManager);
            roomList.setAdapter(roomListAdapter);
            roomListAdapter.setClickListener(MainActivity.this);

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void onClick(View view, int position) {

        Intent intent = new Intent(MainActivity.this,RoomDetailsActivity.class);
        intent.putExtra("KEY",roomListDataArray.get(position).getKey().toString());
        startActivity(intent);

    }
}