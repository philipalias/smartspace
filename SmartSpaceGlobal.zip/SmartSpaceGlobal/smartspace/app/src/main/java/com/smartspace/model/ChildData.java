package com.smartspace.model;


/**
 * Created by Trinity Tuts on 10-01-2015.
 */
public class ChildData {
    
    String key;
    public String getKey() {
        return key;
    }

    public void setKey(String id) {
        this.key = key;
    }

    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    String thumb;

    public String getThumb() {
        return thumb;
    }

    public void setThumb(String thumb) {
        this.thumb = thumb;
    }

}