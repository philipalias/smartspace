package com.smartspace.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.smartspace.R;
import com.smartspace.adapter.ExpandableListAdapter;
import com.smartspace.model.ChildData;
import com.smartspace.services.Webservices;
import com.smartspace.utils.Common;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class RoomDetailsActivity extends AppCompatActivity {
    String API_ROOM_DETAILS = "/room/detail/";

    ImageView bannerImage;
    TextView roomNameTxt;
    TextView roomCapacityTxt;
    TextView roomLocationTxt;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_details);

        bannerImage = (ImageView)findViewById(R.id.bannerImage);
        roomNameTxt = (TextView)findViewById(R.id.roomName);
        roomCapacityTxt = (TextView)findViewById(R.id.roomCapacity);
        roomLocationTxt = (TextView)findViewById(R.id.roomLocation);

        Intent i = getIntent();
        String key = i.getStringExtra("KEY");
        getRoomDetails(key+".json");
    }

    public void getRoomDetails(String key) {
        String url = Common.TAG_API_URL + API_ROOM_DETAILS+key;
        Common.vLog(url);
        Webservices.get(true, this, url, new Webservices.VolleyCallback1() {
            @Override
            public void onSuccess(JSONObject response) {
                try {
                    String key = response.getString("key");
                    String name = response.getString("name");
                    String capacity = response.getString("capacity");
                    String image = response.getString("heroImageUrl");

                    Glide.with(RoomDetailsActivity.this)
                            .load(image)
                            .into(bannerImage);

                    roomNameTxt.setText(name);
                    roomCapacityTxt.setText("Capacity: "+capacity);
                    roomNameTxt.setText(name);

                    JSONObject location = response.getJSONObject("location");
                    String region = location.getJSONObject("region").getString("name");
                    String site = location.getJSONObject("site").getString("name");
                    String building = location.getJSONObject("building").getString("name");
                    String floor = location.getJSONObject("floor").getString("name");

                    roomLocationTxt.setText(floor+", "+building+"\n"+site+", "+region);

                    JSONArray features = response.getJSONArray("features");
                    JSONArray services = response.getJSONArray("services");
                    JSONArray facilities = response.getJSONArray("facilities");
                    JSONArray equipment = response.getJSONArray("equipment");

                    CopyOnWriteArrayList<ChildData> featureDataArray = new CopyOnWriteArrayList<>();
                    if(features.length() > 0){

                        for (int i= 0; i <features.length(); i++){
                            String featuresKey = features.getJSONObject(i).getString("key");
                            String featuresName = features.getJSONObject(i).getString("name");

                            ChildData featureData = new ChildData();
                            featureData.setKey(featuresKey);
                            featureData.setName(featuresName);
                            featureData.setThumb("");

                            featureDataArray.add(featureData);
                        }
                    }

                    CopyOnWriteArrayList<ChildData> serviceDataArray = new CopyOnWriteArrayList<>();
                    if(services.length() > 0){

                        for (int i= 0; i <services.length(); i++){
                            String servicesKey = services.getJSONObject(i).getString("key");
                            String servicesName = services.getJSONObject(i).getString("name");
                            String servicesIcon = services.getJSONObject(i).getString("iconUrl");

                            ChildData serviceData = new ChildData();
                            serviceData.setKey(servicesKey);
                            serviceData.setName(servicesName);
                            serviceData.setThumb(servicesIcon);

                            serviceDataArray.add(serviceData);
                        }
                    }

                    CopyOnWriteArrayList<ChildData> facilitiesDataArray = new CopyOnWriteArrayList<>();
                    if(facilities.length() > 0){

                        for (int i= 0; i <facilities.length(); i++){
                            String facilitiesKey = facilities.getJSONObject(i).getString("key");
                            String facilitiesName = facilities.getJSONObject(i).getString("name");
                            String facilitiesIcon = facilities.getJSONObject(i).getString("iconUrl");

                            ChildData facilitiesData = new ChildData();
                            facilitiesData.setKey(facilitiesKey);
                            facilitiesData.setName(facilitiesName);
                            facilitiesData.setThumb(facilitiesIcon);

                            facilitiesDataArray.add(facilitiesData);
                        }
                    }

                    CopyOnWriteArrayList<ChildData> equipmentDataArray = new CopyOnWriteArrayList<>();
                    if(facilities.length() > 0){

                        for (int i= 0; i <equipment.length(); i++){
                            String equipmentKey = equipment.getJSONObject(i).getString("key");
                            String equipmentName = equipment.getJSONObject(i).getString("name");
                            String equipmentIcon = equipment.getJSONObject(i).getString("iconUrl");

                            ChildData equipmentData = new ChildData();
                            equipmentData.setKey(equipmentKey);
                            equipmentData.setName(equipmentName);
                            equipmentData.setThumb(equipmentIcon);

                            equipmentDataArray.add(equipmentData);
                        }
                    }

                    prepareListData(featureDataArray,serviceDataArray,facilitiesDataArray,equipmentDataArray);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    private void prepareListData(CopyOnWriteArrayList<ChildData> featureDataArray, CopyOnWriteArrayList<ChildData> serviceDataArray,CopyOnWriteArrayList<ChildData> facilitiesDataArray, CopyOnWriteArrayList<ChildData> equipmentDataArray  ){

        try {

            List<String> listDataHeader;
            HashMap<String, List<ChildData>> listDataChild;

            ExpandableListAdapter listAdapter;
            ExpandableListView expListView = (ExpandableListView)findViewById(R.id.specList);

            listDataHeader = new ArrayList<String>();
            listDataChild = new HashMap<String, List<ChildData>>();

            // Adding header data
            listDataHeader.add("Features");
            listDataHeader.add("Services");
            listDataHeader.add("Facilities");
            listDataHeader.add("Equipment");

            listDataChild.put(listDataHeader.get(0),featureDataArray);
            listDataChild.put(listDataHeader.get(1),serviceDataArray);
            listDataChild.put(listDataHeader.get(2),facilitiesDataArray);
            listDataChild.put(listDataHeader.get(3),equipmentDataArray);


            listAdapter = new ExpandableListAdapter(this, listDataHeader, listDataChild);

            // setting list adapter
            expListView.setAdapter(listAdapter);

            // Listview Group click listener
            expListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {

                @Override
                public boolean onGroupClick(ExpandableListView parent, View v,
                                            int groupPosition, long id) {
                    // Toast.makeText(getApplicationContext(),
                    // "Group Clicked " + listDataHeader.get(groupPosition),
                    // Toast.LENGTH_SHORT).show();
                    return false;
                }
            });

            // Listview Group expanded listener
            expListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

                @Override
                public void onGroupExpand(int groupPosition) {
                   /* Toast.makeText(getApplicationContext(),
                            listDataHeader.get(groupPosition) + " Expanded",
                            Toast.LENGTH_SHORT).show();*/
                }
            });

            // Listview Group collasped listener
            expListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

                @Override
                public void onGroupCollapse(int groupPosition) {
                    /*Toast.makeText(getApplicationContext(),
                            listDataHeader.get(groupPosition) + " Collapsed",
                            Toast.LENGTH_SHORT).show();*/

                }
            });

            // Listview on child click listener
            expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

                @Override
                public boolean onChildClick(ExpandableListView parent, View v,
                                            int groupPosition, int childPosition, long id) {
                    // TODO Auto-generated method stub
                   /* Toast.makeText(
                            getApplicationContext(),
                            listDataHeader.get(groupPosition)
                                    + " : "
                                    + listDataChild.get(
                                    listDataHeader.get(groupPosition)).get(
                                    childPosition), Toast.LENGTH_SHORT)
                            .show();*/
                    return false;
                }
            });




        }catch (Exception e){
            e.printStackTrace();
        }
        }
}
