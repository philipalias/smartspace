package com.smartspace.utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Build;
import android.transition.Slide;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.smartspace.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Common {


    public static String TAG_API_URL = "https://ssgmobile.github.io/api";

    static SharedPreferences pref;
    private static boolean isLogEnabled = true;//set it to false in release mode
    private static ProgressDialog progressDialog;
    public static String TAG_PREFRENCE = "myprefrence";
    public static AlertDialog alertDialog = null;
    public static String TAG = "SMARTSPACE";


    public static void Log(String TAG, String MSG) {
        System.out.println(TAG + " : " + MSG);
    }


    public static void vLog(String s) {
        if (isLogEnabled) {
            Log.v(TAG, s);
        }
    }

    public static void showProgressDialog(Context context) {

        try {
            progressDialog = new ProgressDialog(context, R.style.mProgress);
            progressDialog.setCancelable(false);
            progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
            //progressDialog.setIndeterminateDrawable(context.getDrawable(R.drawable.custom_progress_bar));
            progressDialog.show();
            if (!progressDialog.isShowing()) {
                progressDialog.show();
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }


    }

    public static void cancelProgress() {
        //  progressDialog = new ProgressDialog(context);
        try {
            if (progressDialog != null) {
                if (progressDialog.isShowing()) {
                    progressDialog.cancel();
                }
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }


    }

    public static void LogError(Context context, Exception e) {
        //Common.showToast(context, "Error occurred, please check log for details");
        showAlertDialog(context, "Network error","Please check your internet connection.", true,null);
    }

    public static void showToast(Context context, String msg) {

        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    public static void showAlertDialog(final Context context, String title, String message,
                                       Boolean status, final Activity activity) {
        try {
            alertDialog = new AlertDialog.Builder(context).create();

            // Setting Dialog Title
            alertDialog.setTitle(title);

            // Setting Dialog Message
            alertDialog.setMessage(message);
            //alertDialog.setCancelable(iscancel);

            if (status != null)
                // Setting alert dialog icon
                //alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);

                // Setting OK Button
                if (status) {
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            if(activity != null){
                                activity.finish();
                            }

                        }
                    });
                }


            // Showing Alert Message
            alertDialog.show();
        }
        catch (Exception e){
            e.printStackTrace();
        }

    }

    public static void setFontFaceRegular(Context context, TextView textView) {

        Typeface type = Typeface.createFromAsset(context.getAssets(), "fonts/opensans_regular.ttf");
        textView.setTypeface(type);
    }

    public static void setFontFaceRegularEditText(Context context, EditText textView) {

        Typeface type = Typeface.createFromAsset(context.getAssets(), "fonts/opensans_regular.ttf");
        textView.setTypeface(type);
    }

    public static void setFontFaceBold(Context context, TextView textView) {

        Typeface type = Typeface.createFromAsset(context.getAssets(), "fonts/opensans_bold.ttf");
        textView.setTypeface(type);
    }

    public static void saveValueForTag(Context context, String value, String tag) {

        pref = context.getSharedPreferences(TAG_PREFRENCE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(tag, value);
        editor.commit();
    }


    public static String getValueForTag(Context context, String tag) {
        String value = "";
        try {

            pref = context.getSharedPreferences(TAG_PREFRENCE, Context.MODE_PRIVATE);
            value = pref.getString(tag, "");

        }catch (Exception e){
            e.printStackTrace();
        }

        return value;

    }

    public static void setAnimation(Activity activity) {
        if (Build.VERSION.SDK_INT > 20) {
            Slide slide = new Slide();
            slide.setSlideEdge(Gravity.LEFT);
            slide.setDuration(200);
            slide.setInterpolator(new DecelerateInterpolator());
            activity.getWindow().setExitTransition(slide);
            activity.getWindow().setEnterTransition(slide);
        }
    }

    public static void hideSoftKeyboard(Activity activity) {
        try {

            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            View _view = activity.getCurrentFocus();
            if (imm != null) {
                imm.hideSoftInputFromWindow(_view.getWindowToken(), 0);
            }

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public static String formatedPhone1(String phone) {
        String formatedphone = "";
        int phoneNumLength = phone.length();
        if (phoneNumLength == 10) {
            formatedphone = phone.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");
        } else if (phoneNumLength == 11){
            formatedphone = phone.replaceFirst("(\\d)(\\d{3})(\\d{3})(\\d+)", "$1 ($2) $3-$4");
        }
        else if (phoneNumLength == 12 && phone.startsWith("+")){
            formatedphone = phone.replaceFirst("(^\\+?\\d)(\\d{3})(\\d{3})(\\d+)", "$1 ($2) $3-$4");
        }
        else {
            formatedphone = phone;
        }
        return formatedphone;
    }

    public static String formatedPrice(double price){
        return String.format("%.2f", price);
    }
    public static double convertToDouble(String amount){

        return Double.parseDouble(amount);
    }

    public static String hourMinuteZeroPad(int hour, int mnts) {
        String hourZero = (hour >= 10) ? Integer.toString(hour) : String.format("0%s", Integer.toString(hour));
        String minuteZero = (mnts >= 10) ? Integer.toString(mnts) : String.format("0%s", Integer.toString(mnts));
        return hourZero + ":" + minuteZero;
    }

    public static String getFormatedTime(String time){
        String formatedClosetime = "";
        try {
            final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            final Date dateObj = sdf.parse(time);
            System.out.println(dateObj);
            formatedClosetime = new SimpleDateFormat("HH:mm a").format(dateObj);
        } catch (final ParseException e) {
            e.printStackTrace();
        }

        return formatedClosetime;
    }


}
