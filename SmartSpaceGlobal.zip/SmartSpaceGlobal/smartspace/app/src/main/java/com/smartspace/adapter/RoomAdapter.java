package com.smartspace.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.smartspace.R;
import com.smartspace.model.RoomListData;
import com.smartspace.utils.Common;
import com.smartspace.utils.ItemClickListener;
import java.util.concurrent.CopyOnWriteArrayList;

public class RoomAdapter extends RecyclerView.Adapter<RoomAdapter.ViewHolder> {
    private CopyOnWriteArrayList<RoomListData> listdata;
    Context context;
    public ItemClickListener clickListener;

    // RecyclerView recyclerView;
    public RoomAdapter(CopyOnWriteArrayList<RoomListData> listdata, Context context) {
        this.listdata = listdata;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.room_list_items, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final RoomListData data = listdata.get(position);

        holder.roomName.setText(data.getName());
        holder.roomCapacity.setText("Capacity: "+data.getCapacity());

        Common.vLog(data.getName());

        Glide.with(context)
                .load(data.getThumb())
                .into(holder.roomThumb);
    }


    @Override
    public int getItemCount() {
        return listdata.size();
    }

    public void setClickListener(ItemClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public TextView roomName;
        public TextView roomCapacity;
        public ImageView roomThumb;

        public ViewHolder(View itemView) {
            super(itemView);

            this.roomThumb = (ImageView) itemView.findViewById(R.id.roomThumb);
            this.roomName = (TextView) itemView.findViewById(R.id.roomName);
            this.roomCapacity = (TextView) itemView.findViewById(R.id.roomCapacity);
            itemView.setTag(itemView);
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            if (clickListener != null) clickListener.onClick(view, getAdapterPosition());
        }
    }
} 