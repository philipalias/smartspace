package com.smartspace.services;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.smartspace.utils.AppController;
import com.smartspace.utils.Common;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class Webservices extends Service {

    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }

    public static void get(boolean enableloading, final Context context, String url, final VolleyCallback callback) {

        try {
                if(enableloading) {
                    Common.showProgressDialog(context);
                }

                 JsonArrayRequest postRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {

                            try {
                                Common.cancelProgress();
                                Common.vLog(response.toString());
                                callback.onSuccess(response);

                            } catch (Exception e) {
                                e.printStackTrace();
                               // Common.LogError(context,e);
                                Common.cancelProgress();
                                Common.vLog(e.getMessage());
                                //Common.showToast(context,e.getMessage());
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError e) {
                            //Common.LogError(context,e);
                            Common.cancelProgress();
                           // Common.showToast(context,e.getMessage());
                            Common.vLog(e.getMessage());
                            VolleyLog.d("ERROR", "Error: " + e.getMessage());
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    // the POST parameters:
                    return params;
                }


                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    return headers;
                }
            };

            // Access the RequestQueue through your singleton class.
            AppController.getInstance().addToRequestQueue(postRequest);

        } catch (Exception e) {
            e.printStackTrace();
            Common.LogError(context,e);
            Common.cancelProgress();
        }


    }

    public interface VolleyCallback{
        void onSuccess(JSONArray response);
    }


    public static void get(boolean enableloading, final Context context, String url, final VolleyCallback1 callback) {

        try {
            if(enableloading) {
                Common.showProgressDialog(context);
            }

            JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            try {
                                Common.cancelProgress();
                                Common.vLog(response.toString());
                                callback.onSuccess(response);

                            } catch (Exception e) {
                                e.printStackTrace();
                                // Common.LogError(context,e);
                                Common.cancelProgress();
                                Common.vLog(e.getMessage());
                                //Common.showToast(context,e.getMessage());
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError e) {
                            //Common.LogError(context,e);
                            Common.cancelProgress();
                            // Common.showToast(context,e.getMessage());
                            Common.vLog(e.getMessage());
                            VolleyLog.d("ERROR", "Error: " + e.getMessage());
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    // the POST parameters:
                    return params;
                }


                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    return headers;
                }
            };

            // Access the RequestQueue through your singleton class.
            AppController.getInstance().addToRequestQueue(postRequest);

        } catch (Exception e) {
            e.printStackTrace();
            Common.LogError(context,e);
            Common.cancelProgress();
        }


    }

    public interface VolleyCallback1{
        void onSuccess(JSONObject response);
    }

}
